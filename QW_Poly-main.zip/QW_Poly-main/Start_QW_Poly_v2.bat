@echo off
setlocal
cd /d "%~dp0"
title QW Poly v2 - Launcher

where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed.
    echo Install Node.js LTS from https://nodejs.org/ and run this file again.
    pause
    exit /b 1
)
where npm.cmd >nul 2>&1
if errorlevel 1 (
    echo [ERROR] npm was not found. Reinstall Node.js LTS from https://nodejs.org/.
    pause
    exit /b 1
)

if not exist "node_modules\.bin\vite.cmd" goto install
if not exist "node_modules\@esbuild\win32-x64" goto install
goto launch

:install
echo Installing project dependencies...
call npm.cmd install
if errorlevel 1 (
    echo [ERROR] Dependency installation failed.
    pause
    exit /b 1
)

:launch
echo Starting QW Poly v2 at http://localhost:5173/
start "" cmd /c "timeout /t 4 /nobreak >nul & start "" "http://localhost:5173/""
call npm.cmd run dev -- --host 127.0.0.1
if errorlevel 1 (
    echo [ERROR] Server stopped with an error.
    pause
    exit /b 1
)
endlocal
